# k8s_app

This is a Quart-based application to manage Kubernetes resources such as Deployments, Services, ConfigMaps, PersistentVolumes, and PersistentVolumeClaims.

